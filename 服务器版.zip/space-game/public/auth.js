// public/auth.js
// 全局变量存储当前登录用户名
let currentUser = null;

document.addEventListener('DOMContentLoaded', () => {
    const authContainer = document.querySelector('.auth-container');
    const gameContainer = document.getElementById('game-container');
    const authForm = document.querySelector('.auth-form');
    const authError = document.querySelector('.auth-error');
    const authSwitch = document.querySelector('.auth-switch');
    const authTitle = document.querySelector('.auth-title');
    const switchLink = authSwitch.querySelector('a');
    
    // 初始状态：显示登录界面，隐藏游戏界面
    document.getElementById('maze-container').style.display = 'none';
    document.querySelector('.game-controls').style.display = 'none';
    document.querySelector('.keyboard-controls').style.display = 'none';
    document.querySelector('.game-instructions').style.display = 'none';
    document.getElementById('game-info').style.display = 'none';
    
    let isLogin = true;
    
    // 切换登录/注册表单
    switchLink.addEventListener('click', (e) => {
        e.preventDefault();
        isLogin = !isLogin;
        
        if (isLogin) {
            authTitle.textContent = '登录太空站';
            switchLink.textContent = '立即注册';
            authSwitch.firstChild.textContent = '还没有账号？';
        } else {
            authTitle.textContent = '注册新账号';
            switchLink.textContent = '返回登录';
            authSwitch.firstChild.textContent = '已有账号？';
        }
        
        authError.style.display = 'none';
    });
    
    // 处理表单提交
    authForm.addEventListener('submit', async (e) => {
        e.preventDefault();
        const username = authForm.querySelector('input[type="text"]').value;
        const password = authForm.querySelector('input[type="password"]').value;
        
        try {
            const endpoint = isLogin ? '/api/login' : '/api/register';
            const response = await fetch(`http://localhost:3000${endpoint}`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({ username, password })
            });
            
            const data = await response.json();
            
            if (!response.ok) {
                throw new Error(data.message);
            }
            
            if (isLogin) {
                // 登录成功
                currentUser = username;
                authContainer.style.display = 'none';
                document.getElementById('maze-container').style.display = 'grid';
                document.querySelector('.game-controls').style.display = 'block';
                document.querySelector('.keyboard-controls').style.display = 'block';
                document.querySelector('.game-instructions').style.display = 'block';
                document.getElementById('game-info').style.display = 'flex';
                
                // 初始化游戏，传入最高关卡
                if (typeof initGame === 'function') {
                    initGame(data.highestLevel);
                }
            } else {
                // 注册成功，切换到登录表单
                isLogin = true;
                authTitle.textContent = '登录太空站';
                switchLink.textContent = '立即注册';
                authSwitch.firstChild.textContent = '还没有账号？';
                authForm.reset();
                alert('注册成功，请登录');
            }
            
            authError.style.display = 'none';
        } catch (error) {
            authError.textContent = error.message;
            authError.style.display = 'block';
        }
    });

    // 添加用户控制按钮事件处理
    document.getElementById('switchAccount').addEventListener('click', () => {
        currentUser = null;
        document.querySelector('.auth-container').style.display = 'block';
        document.getElementById('maze-container').style.display = 'none';
        document.querySelector('.game-controls').style.display = 'none';
        document.querySelector('.keyboard-controls').style.display = 'none';
        document.querySelector('.game-instructions').style.display = 'none';
        document.getElementById('game-info').style.display = 'none';
        authForm.reset();
    });

    document.getElementById('logout').addEventListener('click', () => {
        currentUser = null;
        window.location.reload();
    });
});

// 导出当前用户名，供其他模块使用
window.getCurrentUser = () => currentUser;