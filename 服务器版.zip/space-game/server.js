const express = require('express');
const sqlite3 = require('sqlite3').verbose();
const bcrypt = require('bcrypt');
const cors = require('cors');
const path = require('path');

const app = express();
const port = 3000;

// 中间件配置
app.use(cors());
app.use(express.json());
app.use(express.static('public'));

// 连接数据库
const db = new sqlite3.Database('users.db', (err) => {
    if (err) {
        console.error('数据库连接失败:', err);
    } else {
        console.log('成功连接到数据库');
        // 创建用户表
        db.run(`CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            username TEXT UNIQUE,
            password TEXT,
            highest_level INTEGER DEFAULT 1
        )`);
    }
});

// 注册接口
app.post('/api/register', async (req, res) => {
    const { username, password } = req.body;
    try {
        // 检查用户名是否已存在
        db.get('SELECT * FROM users WHERE username = ?', [username], async (err, user) => {
            if (err) {
                return res.status(500).json({ message: '服务器错误' });
            }
            if (user) {
                return res.status(400).json({ message: '用户名已存在' });
            }

            // 加密密码
            const hashedPassword = await bcrypt.hash(password, 10);

            // 创建新用户
            db.run('INSERT INTO users (username, password) VALUES (?, ?)',
                [username, hashedPassword],
                (err) => {
                    if (err) {
                        return res.status(500).json({ message: '注册失败' });
                    }
                    res.json({ message: '注册成功' });
                }
            );
        });
    } catch (error) {
        res.status(500).json({ message: '服务器错误' });
    }
});

// 登录接口
app.post('/api/login', async (req, res) => {
    const { username, password } = req.body;
    try {
        db.get('SELECT * FROM users WHERE username = ?', [username], async (err, user) => {
            if (err) {
                return res.status(500).json({ message: '服务器错误' });
            }
            if (!user) {
                return res.status(401).json({ message: '用户名或密码错误' });
            }

            const validPassword = await bcrypt.compare(password, user.password);
            if (!validPassword) {
                return res.status(401).json({ message: '用户名或密码错误' });
            }

            res.json({
                message: '登录成功',
                highestLevel: user.highest_level
            });
        });
    } catch (error) {
        res.status(500).json({ message: '服务器错误' });
    }
});

// 更新最高关卡
app.post('/api/update-level', async (req, res) => {
    const { username, level } = req.body;
    try {
        db.run('UPDATE users SET highest_level = ? WHERE username = ? AND highest_level < ?',
            [level, username, level],
            (err) => {
                if (err) {
                    return res.status(500).json({ message: '更新失败' });
                }
                res.json({ message: '更新成功' });
            }
        );
    } catch (error) {
        res.status(500).json({ message: '服务器错误' });
    }
});

// 启动服务器
app.listen(port, () => {
    console.log(`服务器运行在 http://localhost:${port}`);
});

