window.__INTERNAL__GAME__SDK__ = new GameSdk();

class GameSdk {
    updateGameWin() {
        // 游戏胜利逻辑
        console.log('Game win state updated');
    }
    
    updateGameLoss() {
        // 游戏失败逻辑
        console.log('Game loss state updated');
    }
    
    updateGameLevel(level) {
        // 关卡更新逻辑
        console.log(`Game level updated to ${level}`);
    }
    
    resetGameWinAndLoss() {
        // 重置游戏胜利和失败状态
        console.log('Game win and loss states reset');
    }
}