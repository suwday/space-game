document.addEventListener('DOMContentLoaded', () => {

	const mazeContainer = document.getElementById('maze-container');
	const levelDisplay = document.getElementById('level');
	const stepsDisplay = document.getElementById('steps');
	const restartButton = document.getElementById('restart');
	const resetButton = document.getElementById('reset');

	const baseSize = 10; // 修改基础地图大小为10x10
	const cellSize = 35;

	let level = 1;
	let mazeSize = baseSize;
	let maze = [];
	let playerPosition = {
		x: 0,
		y: 0
	};
	let redApples = [];
	let poisonApples = [];
	let steps = 0;
	let isPlaying = false;
	let movesHistory = [];

	// 陨石相关
	const meteorInterval = 3000; // 保持陨石移动间隔不变

	const DIRECTIONS = {
		UP: {
			x: 0,
			y: -1
		},
		RIGHT: {
			x: 1,
			y: 0
		},
		DOWN: {
			x: 0,
			y: 1
		},
		LEFT: {
			x: -1,
			y: 0
		}
	};

	const CELL_TYPES = {
		WALL: 0,
		PATH: 1,
		ASTRONAUT: 2,
		BATTERY: 3,
		METEOR: 4,
		VISITED: 5
	};

	const CELL_CLASSES = {
		[CELL_TYPES.WALL]: 'wall',
		[CELL_TYPES.PATH]: 'path',
		[CELL_TYPES.ASTRONAUT]: 'astronaut',
		[CELL_TYPES.BATTERY]: 'battery',
		[CELL_TYPES.METEOR]: 'meteor',
		[CELL_TYPES.VISITED]: 'visited'
	};

	function createMazeHTML() {
		mazeContainer.innerHTML = '';
		mazeContainer.style.gridTemplateColumns = `repeat(${mazeSize}, ${cellSize}px)`;
		mazeContainer.style.gridTemplateRows = `repeat(${mazeSize}, ${cellSize}px)`;

		for (let y = 0; y < mazeSize; y++) {
			for (let x = 0; x < mazeSize; x++) {
				const cell = document.createElement('div');
				cell.classList.add('cell');

				if (x === playerPosition.x && y === playerPosition.y) {
					cell.classList.add(CELL_CLASSES[CELL_TYPES.ASTRONAUT]);
				} else if (redApples.some(pos => pos.x === x && pos.y === y)) {
					cell.classList.add(CELL_CLASSES[CELL_TYPES.BATTERY]);
				} else if (poisonApples.some(pos => pos.x === x && pos.y === y)) {
					cell.classList.add(CELL_CLASSES[CELL_TYPES.METEOR]);
				} else {
					cell.classList.add(CELL_CLASSES[maze[y][x]]);
				}

				cell.dataset.x = x;
				cell.dataset.y = y;
				mazeContainer.appendChild(cell);
			}
		}
	}

	function updateMazeDisplay() {
		const cells = mazeContainer.querySelectorAll('.cell');
		cells.forEach(cell => {
			const x = parseInt(cell.dataset.x);
			const y = parseInt(cell.dataset.y);

			Object.values(CELL_CLASSES).forEach(className => {
				cell.classList.remove(className);
			});

			if (x === playerPosition.x && y === playerPosition.y) {
				cell.classList.add(CELL_CLASSES[CELL_TYPES.ASTRONAUT]);
			} else if (redApples.some(pos => pos.x === x && pos.y === y)) {
				cell.classList.add(CELL_CLASSES[CELL_TYPES.BATTERY]);
			} else if (poisonApples.some(pos => pos.x === x && pos.y === y)) {
				cell.classList.add(CELL_CLASSES[CELL_TYPES.METEOR]);
			} else if (movesHistory.some(pos => pos.x === x && pos.y === y)) {
				cell.classList.add(CELL_CLASSES[CELL_TYPES.VISITED]);
			} else {
				cell.classList.add(CELL_CLASSES[maze[y][x]]);
			}
		});
	}

	function isPositionReachable(startX, startY, targetX, targetY) {
		const visited = new Set();
		const queue = [{
			x: startX,
			y: startY
		}];
		visited.add(`${startX},${startY}`);

		while (queue.length > 0) {
			const current = queue.shift();
			if (current.x === targetX && current.y === targetY) return true;

			for (const dir of Object.values(DIRECTIONS)) {
				const nx = current.x + dir.x;
				const ny = current.y + dir.y;

				if (nx >= 0 && nx < mazeSize && ny >= 0 && ny < mazeSize &&
					maze[ny][nx] !== CELL_TYPES.WALL && !visited.has(`${nx},${ny}`)) {
					queue.push({
						x: nx,
						y: ny
					});
					visited.add(`${nx},${ny}`);
				}
			}
		}
		return false;
	}

	function shuffleArray(array) {
		const result = [...array];
		for (let i = result.length - 1; i > 0; i--) {
			const j = Math.floor(Math.random() * (i + 1));
			[result[i], result[j]] = [result[j], result[i]];
		}
		return result;
	}

	function generateMaze() {
		function generateValidPositions() {
			const positions = {
				dwarf: null,
				redApples: [],
				poisonApples: []
			};

			// 修改玩家出生点生成逻辑，增加出生点多样性
			const spawnSide = Math.floor(Math.random() * 4);
			switch (spawnSide) {
				case 0: // 上边
					positions.dwarf = {
						x: Math.floor(Math.random() * (mazeSize - 2)) + 1,
						y: 1
					};
					break;
				case 1: // 右边
					positions.dwarf = {
						x: mazeSize - 2,
						y: Math.floor(Math.random() * (mazeSize - 2)) + 1
					};
					break;
				case 2: // 下边
					positions.dwarf = {
						x: Math.floor(Math.random() * (mazeSize - 2)) + 1,
						y: mazeSize - 2
					};
					break;
				case 3: // 左边
					positions.dwarf = {
						x: 1,
						y: Math.floor(Math.random() * (mazeSize - 2)) + 1
					};
					break;
			}

			// 调整能量电池数量计算公式，适应15关
			const numRedApples = Math.min(2 + Math.floor((level - 1) / 3), 7);
			// 调整陨石数量计算公式
			const numPoisonApples = Math.min(
				Math.max(2, Math.floor(numRedApples * 0.75)), 
				Math.floor((mazeSize - 4) / 2)
			);
			const maxAttempts = 50;

			for (let i = 0; i < numRedApples; i++) {
				let attempts = 0;
				let applePosition;

				do {
					attempts++;
					if (numRedApples <= 3) {
						if (Math.random() < 0.5) {
							applePosition = {
								x: mazeSize - 1,
								y: Math.floor(Math.random() * (mazeSize - 2)) + 1
							};
						} else {
							applePosition = {
								x: Math.floor(Math.random() * (mazeSize - 2)) + 1,
								y: mazeSize - 1
							};
						}
					} else {
						const side = Math.floor(Math.random() * 4);
						switch (side) {
							case 0:
								applePosition = {
									x: Math.floor(Math.random() * (mazeSize - 2)) + 1,
									y: 0
								};
								break;
							case 1:
								applePosition = {
									x: mazeSize - 1,
									y: Math.floor(Math.random() * (mazeSize - 2)) + 1
								};
								break;
							case 2:
								applePosition = {
									x: Math.floor(Math.random() * (mazeSize - 2)) + 1,
									y: mazeSize - 1
								};
								break;
							case 3:
								applePosition = {
									x: 0,
									y: Math.floor(Math.random() * (mazeSize - 2)) + 1
								};
								break;
						}
					}

					const isOccupied = positions.redApples.some(pos =>
						pos.x === applePosition.x && pos.y === applePosition.y
					) || positions.poisonApples.some(pos =>
						pos.x === applePosition.x && pos.y === applePosition.y
					);

					const isDwarfPosition = applePosition.x === positions.dwarf.x &&
						applePosition.y === positions.dwarf.y;

					if (!isOccupied && !isDwarfPosition) {
						positions.redApples.push(applePosition);
						break;
					}

					if (attempts >= maxAttempts) return null;
				} while (true);
			}

			for (let i = 0; i < numPoisonApples; i++) {
				let attempts = 0;
				let applePosition;

				do {
					attempts++;
					applePosition = {
						x: Math.floor(Math.random() * (mazeSize - 2)) + 1,
						y: Math.floor(Math.random() * (mazeSize - 2)) + 1
					};

					const isOccupied = positions.redApples.some(pos =>
						pos.x === applePosition.x && pos.y === applePosition.y
					) || positions.poisonApples.some(pos =>
						pos.x === applePosition.x && pos.y === applePosition.y
					);

					const isDwarfPosition = applePosition.x === positions.dwarf.x &&
						applePosition.y === positions.dwarf.y;

					if (!isOccupied && !isDwarfPosition) {
						positions.poisonApples.push(applePosition);
						break;
					}

					if (attempts >= maxAttempts) return null;
				} while (true);
			}

			return positions;
		}

		let positions;
		do {
			positions = generateValidPositions();
		} while (!positions);

		maze = Array(mazeSize).fill().map(() => Array(mazeSize).fill(CELL_TYPES.WALL));

		playerPosition = positions.dwarf;
		maze[playerPosition.y][playerPosition.x] = CELL_TYPES.PATH;

		redApples = positions.redApples;
		redApples.forEach(pos => {
			maze[pos.y][pos.x] = CELL_TYPES.PATH;
		});

		poisonApples = positions.poisonApples;
		poisonApples.forEach(pos => {
			maze[pos.y][pos.x] = CELL_TYPES.PATH;
		});

		function carvePath(x, y) {
			const directions = shuffleArray(Object.values(DIRECTIONS));

			for (const dir of directions) {
				const nx = x + dir.x * 2;
				const ny = y + dir.y * 2;

				if (nx > 0 && nx < mazeSize - 1 && ny > 0 && ny < mazeSize - 1 &&
					maze[ny][nx] === CELL_TYPES.WALL) {
					maze[y + dir.y][x + dir.x] = CELL_TYPES.PATH;
					maze[ny][nx] = CELL_TYPES.PATH;
					carvePath(nx, ny);
				}
			}
		}

		carvePath(playerPosition.x, playerPosition.y);

		for (const applePos of [...redApples]) {
			if (!isPositionReachable(playerPosition.x, playerPosition.y, applePos.x, applePos.y)) {
				return generateMaze();
			}
		}

		const poisonCells = new Set(poisonApples.map(pos => `${pos.x},${pos.y}`));
		for (const applePos of redApples) {
			const visited = new Set();
			const queue = [{
				x: playerPosition.x,
				y: playerPosition.y
			}];
			visited.add(`${playerPosition.x},${playerPosition.y}`);
			let canReach = false;

			while (queue.length > 0) {
				const current = queue.shift();
				if (current.x === applePos.x && current.y === applePos.y) {
					canReach = true;
					break;
				}

				for (const dir of Object.values(DIRECTIONS)) {
					const nx = current.x + dir.x;
					const ny = current.y + dir.y;
					const key = `${nx},${ny}`;

					if (nx >= 0 && nx < mazeSize && ny >= 0 && ny < mazeSize &&
						maze[ny][nx] !== CELL_TYPES.WALL &&
						!visited.has(key) &&
						!poisonCells.has(key)) {
						queue.push({
							x: nx,
							y: ny
						});
						visited.add(key);
					}
				}
			}

			if (!canReach) {
				return generateMaze();
			}
		}
	}

	function showWinMessage() {
		const winMessage = document.getElementById('win-message');
		const status = document.getElementById('status');
		status.textContent = '恭喜吃到所有能量电池！';
		winMessage.classList.add('visible');

		setTimeout(() => {
			winMessage.classList.remove('visible');
			status.textContent = '游戏中';
			level++;
			// 调整地图增长逻辑
			if (level <= 15) { // 限制最大关卡数为15
				if (level % 2 === 0) { // 每2关增加地图大小
					mazeSize = baseSize + 2 * Math.floor(level / 2);
				}
				restartGame();
			} else {
				// 通关后显示祝贺信息
				status.textContent = '恭喜通关所有关卡！';
				setTimeout(() => {
					resetToFirstLevel();
				}, 3000);
			}
		}, 2000);

		//使用GameSDK更新游戏状态
		window.__INTERNAL__GAME__SDK__.updateGameWin();
	}

	function showLossMessage() {
		const winMessage = document.getElementById('win-message');
		const status = document.getElementById('status');
		status.textContent = '撞到陨石碎片了！';
		winMessage.classList.add('visible');

		setTimeout(() => {
			winMessage.classList.remove('visible');
			status.textContent = '游戏中';
			restartGame();
		}, 2000);

		//使用GameSDK更新游戏状态
		window.__INTERNAL__GAME__SDK__.updateGameLoss();
	}

	function movePlayer(direction) {
		if (!isPlaying) return;

		const newX = playerPosition.x + direction.x;
		const newY = playerPosition.y + direction.y;

		if (newX >= 0 && newX < mazeSize && newY >= 0 && newY < mazeSize &&
			maze[newY][newX] !== CELL_TYPES.WALL) {

			movesHistory.push({
				...playerPosition
			});
			playerPosition.x = newX;
			playerPosition.y = newY;
			steps++;
			stepsDisplay.textContent = steps;
			updateMazeDisplay();

			const redAppleIndex = redApples.findIndex(pos =>
				pos.x === playerPosition.x && pos.y === playerPosition.y
			);

			if (redAppleIndex !== -1) {
				redApples.splice(redAppleIndex, 1);
				updateMazeDisplay();

				if (redApples.length === 0) {
					isPlaying = false;
					showWinMessage();
				}
			}

			const poisonAppleIndex = poisonApples.findIndex(pos =>
				pos.x === playerPosition.x && pos.y === playerPosition.y
			);

			if (poisonAppleIndex !== -1) {
				isPlaying = false;
				showLossMessage();
			}
		}
	}

	function startGame() {
		isPlaying = true;
		steps = 0;
		movesHistory = [];
		redApples = [];
		poisonApples = [];

		stepsDisplay.textContent = steps;
		generateMaze();
		createMazeHTML();
		levelDisplay.textContent = level;

		//使用GameSDK更新游戏状态
		window.__INTERNAL__GAME__SDK__.updateGameLevel(level);
	}

	function restartGame() {
		isPlaying = false;
		startGame();
	}

	function resetToFirstLevel() {
		level = 1;
		mazeSize = baseSize;
		restartGame();

		//使用GameSDK更新游戏状态
		window.__INTERNAL__GAME__SDK__.resetGameWinAndLoss();
		window.__INTERNAL__GAME__SDK__.updateGameLevel(level);
	}

	function loadGameData() {
		const savedData = localStorage.getItem('mazeGameData');
		if (savedData) {
			const data = JSON.parse(savedData);
			level = data.level || 1;
			mazeSize = baseSize + 2 * Math.floor((level - 1) / 3);
		}
	}

	function saveGameData() {
		localStorage.setItem('mazeGameData', JSON.stringify({
			level,
			mazeSize
		}));
	}

	function moveMeteors() {
		poisonApples.forEach(meteor => {
			const directions = [{
					dx: 0,
					dy: -1
				}, // 上
				{
					dx: 1,
					dy: 0
				}, // 右
				{
					dx: 0,
					dy: 1
				}, // 下
				{
					dx: -1,
					dy: 0
				} // 左
			].filter(dir => {
				const newX = meteor.x + dir.dx;
				const newY = meteor.y + dir.dy;
				return newX >= 0 && newX < mazeSize &&
					newY >= 0 && newY < mazeSize &&
					maze[newY][newX] === CELL_TYPES.PATH;
			});

			if (directions.length > 0) {
				const dir = directions[Math.floor(Math.random() * directions.length)];
				meteor.x += dir.dx;
				meteor.y += dir.dy;
			}
		});
		updateMazeDisplay();

		// 检查碰撞
		if (poisonApples.some(m => m.x === playerPosition.x && m.y === playerPosition.y)) {
			isPlaying = false;
			showLossMessage();
		}
	}

	// 每3秒移动一次陨石
	setInterval(moveMeteors, meteorInterval);

	function init() {
		loadGameData();

		document.addEventListener('keydown', e => {
			switch (e.key) {
				case 'ArrowUp':
					movePlayer(DIRECTIONS.UP);
					break;
				case 'ArrowRight':
					movePlayer(DIRECTIONS.RIGHT);
					break;
				case 'ArrowDown':
					movePlayer(DIRECTIONS.DOWN);
					break;
				case 'ArrowLeft':
					movePlayer(DIRECTIONS.LEFT);
					break;
			}
		});

		restartButton.addEventListener('click', restartGame);
		resetButton.addEventListener('click', resetToFirstLevel);

		document.querySelectorAll('.key').forEach(key => {
			key.addEventListener('click', () => {
				const direction = key.getAttribute('data-direction');
				if (direction === 'up') movePlayer(DIRECTIONS.UP);
				else if (direction === 'right') movePlayer(DIRECTIONS.RIGHT);
				else if (direction === 'down') movePlayer(DIRECTIONS.DOWN);
				else if (direction === 'left') movePlayer(DIRECTIONS.LEFT);
			});
		});

		startGame();
		window.addEventListener('beforeunload', saveGameData);
	}

	if (document.readyState === 'loading') {
		document.addEventListener('DOMContentLoaded', init);
	} else {
		init();
	}
});